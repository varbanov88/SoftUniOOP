﻿using System;

namespace CardPower
{
    public class StartUp
    {
        public static void Main()
        {
            Rank cardRank = (Rank)Enum.Parse(typeof(Rank), Console.ReadLine());
            Suit cardSuit = (Suit)Enum.Parse(typeof(Suit), Console.ReadLine());
            var card = new Card(cardRank, cardSuit);
            Rank secondCardRank = (Rank)Enum.Parse(typeof(Rank), Console.ReadLine());
            Suit secondCardSuit = (Suit)Enum.Parse(typeof(Suit), Console.ReadLine());
            var secondCard = new Card(secondCardRank, secondCardSuit);

            var result = card.CompareTo(secondCard);

            Console.WriteLine(result == 1 ? card : secondCard);
        }
    }
}
