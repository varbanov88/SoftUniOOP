﻿using System;

namespace CardPower
{
    public class StartUp
    {
        public static void Main()
        {
            Rank cardRank = (Rank)Enum.Parse(typeof(Rank), Console.ReadLine());
            Suit cardSuit = (Suit)Enum.Parse(typeof(Suit), Console.ReadLine());
            var card = new Card(cardRank, cardSuit);

            Console.WriteLine(card);
        }
    }
}
