﻿using System;

namespace CardPower
{
    public class Card : IComparable<Card>
    {
        public Card(Rank rank, Suit suit)
        {
            this.Rank = rank;
            this.Suit = suit;
            this.Power = (int)this.Rank + (int)this.Suit;
        }

        public Rank Rank { get; set; }

        public Suit Suit { get; set; }

        public int Power { get; private set; }

        public int CompareTo(Card other)
        {
            return this.Power.CompareTo(other.Power);
        }

        public override string ToString()
        {
            return $"Card name: {this.Rank} of {this.Suit}; Card power: {Power}";
        }
    }
}
